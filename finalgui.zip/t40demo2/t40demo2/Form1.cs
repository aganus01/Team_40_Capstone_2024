using System.Data;
using System.Timers;
using static System.Windows.Forms.LinkLabel;
using System.Net;
using System.Net.Sockets;

namespace t40demo2
{
    public partial class Form1 : Form
    {
        bool swap = false;
        Random rnd = new Random();
        DataTable dt;
        public Form1()
        {
            InitializeComponent();

        }

        string[] statusMsg =
        {
            "Press [Connect] to connect to the Radiation Test Board!",
            "Connection failed!",
            "Input your voltage and temp then press [Start] to run the test!",
            "Invalid parameters",
            "Test Stopped",
            "Exported!",
            "Test started"
        };

        private void Form1_Load(object sender, EventArgs e)
        {
            statusBox.Text = statusMsg[0];
        }

        private void toolStripContainer1_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            swap = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool boundsCheck = false;
            

            if (voltBox.Text == "[Voltage]" || tempBox.Text == "[Temp]" || boundsCheck)
            {
                statusBox.Text = statusMsg[3];
                
            }
            else
            {
                string tVolt = voltBox.Text;
                string tTemp = tempBox.Text;
                if (swap)
                {
                    dt = new DataTable();
                    dt.Columns.Add("TIME");
                    dt.Columns.Add("TestVolt");
                    dt.Columns.Add("TestTemp");
                    dt.Columns.Add("Rec TEMP");
                    for (int i = 1; i <= 30; i++)
                    {
                        dt.Rows.Add(i, tVolt, tTemp, rnd.Next(0, 125));
                    }
                    dataGridView1.DataSource = dt;
                    swap = false;
                    statusBox.Text = statusMsg[6];
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            swap = false;
            statusBox.Text = statusMsg[4];
        }
        private void exportCsvButton_Click(object sender, EventArgs e)
        {
            printToCsv();
        }

        private void connectTCP_Click(object sender, EventArgs e)
        {
            //SocketListener soc1 = new SocketListener();
            statusBox.Text = statusMsg[2];
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void printToCsv()
        {
            string docPath =
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, DateTime.Now.ToString("HH_mm_ss") + "_demoData.txt")))
            {
                foreach (DataRow dr in dt.Rows)
                {
                    foreach (var item in dr.ItemArray)
                    {
                        outputFile.Write(item + ",");
                    }
                    outputFile.WriteLine();
                }

            }
            statusBox.Text = statusMsg[5];
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
