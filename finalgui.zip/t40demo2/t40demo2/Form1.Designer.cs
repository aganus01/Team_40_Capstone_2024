﻿using System.Data;
using System.Windows.Forms;

namespace t40demo2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            comboBox1 = new ComboBox();
            startBtn = new Button();
            stopBtn = new Button();
            exportCsvButton = new Button();
            dataGridView1 = new DataGridView();
            timer2 = new System.Windows.Forms.Timer(components);
            connectTCP = new Button();
            voltBox = new TextBox();
            tempBox = new TextBox();
            statusBox = new RichTextBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "DUT [1]", "DUT [2]", "DUT [3]", "DUT [4]", "DUT [5]", "DUT [6]" });
            comboBox1.Location = new Point(12, 7);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(182, 28);
            comboBox1.TabIndex = 0;
            comboBox1.Text = "DUT [1]";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // startBtn
            // 
            startBtn.BackColor = Color.LawnGreen;
            startBtn.Location = new Point(203, 3);
            startBtn.Name = "startBtn";
            startBtn.Size = new Size(112, 34);
            startBtn.TabIndex = 2;
            startBtn.Tag = "canStart";
            startBtn.Text = "Start";
            startBtn.UseVisualStyleBackColor = false;
            startBtn.Click += button1_Click;
            // 
            // stopBtn
            // 
            stopBtn.BackColor = Color.Red;
            stopBtn.ForeColor = Color.Black;
            stopBtn.Location = new Point(649, 6);
            stopBtn.Name = "stopBtn";
            stopBtn.Size = new Size(112, 34);
            stopBtn.TabIndex = 3;
            stopBtn.Tag = "canStop";
            stopBtn.Text = "Stop";
            stopBtn.UseVisualStyleBackColor = false;
            stopBtn.Click += button2_Click;
            // 
            // exportCsvButton
            // 
            exportCsvButton.BackColor = Color.CadetBlue;
            exportCsvButton.Location = new Point(718, 377);
            exportCsvButton.Name = "exportCsvButton";
            exportCsvButton.Size = new Size(112, 34);
            exportCsvButton.TabIndex = 4;
            exportCsvButton.Tag = "canExportCsv";
            exportCsvButton.Text = "Export CSV";
            exportCsvButton.UseVisualStyleBackColor = false;
            exportCsvButton.Click += exportCsvButton_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = SystemColors.Control;
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 47);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(612, 373);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // connectTCP
            // 
            connectTCP.BackColor = SystemColors.ButtonShadow;
            connectTCP.Location = new Point(767, 7);
            connectTCP.Name = "connectTCP";
            connectTCP.Size = new Size(112, 34);
            connectTCP.TabIndex = 5;
            connectTCP.Tag = "canConnect";
            connectTCP.Text = "Connect";
            connectTCP.UseVisualStyleBackColor = false;
            connectTCP.Click += connectTCP_Click;
            // 
            // voltBox
            // 
            voltBox.Location = new Point(321, 6);
            voltBox.Name = "voltBox";
            voltBox.Size = new Size(70, 27);
            voltBox.TabIndex = 6;
            voltBox.Text = "[Voltage]\r\n\r\n";
            voltBox.TextAlign = HorizontalAlignment.Center;
            voltBox.TextChanged += textBox1_TextChanged;
            // 
            // tempBox
            // 
            tempBox.Location = new Point(456, 6);
            tempBox.Name = "tempBox";
            tempBox.Size = new Size(92, 27);
            tempBox.TabIndex = 7;
            tempBox.Text = "[Temp]";
            tempBox.TextAlign = HorizontalAlignment.Center;
            tempBox.TextChanged += textBox2_TextChanged;
            // 
            // statusBox
            // 
            statusBox.Location = new Point(649, 47);
            statusBox.Name = "statusBox";
            statusBox.ReadOnly = true;
            statusBox.Size = new Size(230, 313);
            statusBox.TabIndex = 9;
            statusBox.Text = "Press [Connect] to connect to the Radiation Test Board!";
            statusBox.TextChanged += richTextBox1_TextChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(397, 6);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(53, 27);
            textBox1.TabIndex = 10;
            textBox1.Text = "(Volts)";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(554, 6);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(66, 27);
            textBox2.TabIndex = 11;
            textBox2.Text = "(Celsius)";
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // Form1
            // 
            ClientSize = new Size(892, 453);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(statusBox);
            Controls.Add(tempBox);
            Controls.Add(voltBox);
            Controls.Add(connectTCP);
            Controls.Add(dataGridView1);
            Controls.Add(exportCsvButton);
            Controls.Add(stopBtn);
            Controls.Add(startBtn);
            Controls.Add(comboBox1);
            Name = "Form1";
            Load += Form1_Load_1;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private SplitContainer splitContainer1;
        private Button startBtn;
        private Button stopBtn;
        private Button exportCsvButton;
        private DataGridView dataGridView1;
        private System.Windows.Forms.Timer timer2;
        private Button connectTCP;
        private TextBox voltBox;
        private TextBox tempBox;
        private RichTextBox statusBox;
        private TextBox textBox1;
        private TextBox textBox2;
    }
}
